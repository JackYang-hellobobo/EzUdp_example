import socket
hostip = socket.gethostbyname(socket.gethostname())
print(hostip)